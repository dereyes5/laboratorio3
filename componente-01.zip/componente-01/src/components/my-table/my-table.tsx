import { Component, Host, h, State } from '@stencil/core';

export interface UsersDataInterface {
  name: string;
  username: string;
  email: string;
  phone: string;
}

@Component({
  tag: 'my-table',
  styleUrl: 'my-table.css',
  shadow: true,
})
export class MyTable {

  @State() usersData: Array<UsersDataInterface> = [];

  private onClickHola() {
    alert('Hola');
  }

  private fetchUsers() {
    let url = 'https://jsonplaceholder.typicode.com/users';
    fetch(url)
      .then(response => {
        if (response.status !== 200) {
          throw new Error('No se pudo conectar');
        }
        return response.json();
      })
      .then(json => {
        this.usersData = json; // Asignar los datos obtenidos a la variable usersData
      })
      .catch(error => {
        console.log(error);
      });
  }

  componentWillLoad() {
    this.fetchUsers();
  }

  render() {
    return (
      <Host>
        <custom-button onClick={this.onClickHola.bind(this)}>Hola</custom-button>
        <table>
          <thead>
            <tr>
              <th>Id</th>
              <th>Nombre</th>
              <th>Usuario</th>
              <th>Email</th>
              <th>Telefono</th>
            </tr>
          </thead>
          <tbody>
            {
              this.usersData.map((el,index) => {
                return(
                  <tr>
                    <td>{index+1}</td>
                    <td>{el.name}</td>
                    <td>{el.username}</td>
                    <td>{el.email}</td>
                    <td>{el.phone}</td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </Host>
    );
  }
}
