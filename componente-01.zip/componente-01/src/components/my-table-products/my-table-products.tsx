import { Component, Host, h, State } from '@stencil/core';

export interface UsersDataInterface {
  id: number;
  name: string;
  description: string;
  stock: number;
}

@Component({
  tag: 'my-table-products',
  styleUrl: 'my-table-products.css',
  shadow: true,
})
export class MyTable {

  @State() usersData: Array<UsersDataInterface> = [];

  private onClickHola() {
    alert('Hola');
  }

  private fetchUsers() {
    let url = 'localhost:8080/products';
    fetch(url)
      .then(response => {
        if (response.status !== 200) {
          throw new Error('No se pudo conectar');
        }
        return response.json();
      })
      .then(json => {
        this.usersData = json; // Asignar los datos obtenidos a la variable usersData
      })
      .catch(error => {
        console.log(error);
      });
  }

  componentWillLoad() {
    this.fetchUsers();
  }

  render() {
    return (
      <Host>
        <custom-button onClick={this.onClickHola.bind(this)}>Hola</custom-button>
        <table>
          <thead>
          <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Usuario</th>
            <th>Email</th>
            <th>Telefono</th>
          </tr>
          </thead>
          <tbody>
          {
            this.usersData.map((el,id) => {
              return(
                <tr>
                  <td>{id}</td>
                  <td>{el.name}</td>
                  <td>{el.description}</td>
                  <td>{el.stock}</td>
                </tr>
              )
            })
          }
          </tbody>
        </table>
      </Host>
    );
  }
}
