import { Component,h, Prop } from "@stencil/core";

@Component({
  tag: "custom-button",
  styleUrl: "button.css",
  shadow: true
})
export class CustomButton{
  @Prop({reflect: true,mutable: true})
  color: string;
  render(){
    return <button class={this.color}><slot></slot></button>
  }
}
