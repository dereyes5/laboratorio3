import { Component, Host, h, Prop } from '@stencil/core';

@Component({
  tag: 'my-card',
  styleUrl: 'my-card.css',
  shadow: true,
})
export class MyCard {
  @Prop({reflect:true,mutable:true}) h2: string;
  @Prop({reflect:true,mutable:true}) p: string;
  @Prop() url: string = 'https://th.bing.com/th/id/R.3cc84035a9f175d38139b718c5c60e73?rik=1hEla21le%2f2Zhw&riu=http%3a%2f%2fwww.pngall.com%2fwp-content%2fuploads%2f5%2fProfile-PNG-Free-Download.png&ehk=KTE%2bcnU8tbMRQTVE9RJUoH59ReP%2bgFtzIpw%2bNRRXN1s%3d&risl=&pid=ImgRaw&r=0';
  render() {
      return (
        <Host>
          <div class="card">
            <img src={this.url} alt="Profile Picture" class="profile-picture" />
            <div class="card-content">
              <h2 class="name">{this.h2}</h2>
              <p class="phone">{this.p}</p>
            </div>
          </div>
        </Host>
      );
  }

}
